const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const mysql = require('mysql');

const app = express();
app.use(bodyParser.json());
app.use(cors());

const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'password',
    database: 'sampledb'
});

db.connect(err => {
    if (err) {
        throw err;
    }
    console.log('MySQL Connected...');
});

// User registration
app.post('/signup', async (req, res) => {
    const { name, email, mobile, password, confirmPassword } = req.body;

    if (password !== confirmPassword) {
        return res.status(400).json({ msg: 'Passwords do not match' });
    }

    const hashedPassword = await bcrypt.hash(password, 8);

    let sql = INSERT INTO users (name, email, mobile, password) VALUES ('${name}', '${email}', '${mobile}', '${hashedPassword}');
    
    db.query(sql, (err, result) => {
        if (err) {
            if (err.code === 'ER_DUP_ENTRY') {
                return res.status(400).json({ msg: 'User already exists' });
            }
            throw err;
        }
        res.status(200).json({ msg: 'User registered' });
    });
});

// User login
app.post('/signin', async (req, res) => {
    const { email, password } = req.body;

    let sql = SELECT * FROM users WHERE email = '${email}' OR mobile = '${email}';
    
    db.query(sql, async (err, results) => {
        if (err) throw err;

        if (results.length === 0 || !(await bcrypt.compare(password, results[0].password))) {
            return res.status(400).json({ msg: 'Invalid credentials' });
        }

        const token = jwt.sign({ id: results[0].id }, 'secretkey', { expiresIn: '10m' });

        res.status(200).json({ token });
    });
});

// Middleware to protect routes
const authenticateToken = (req, res, next) => {
    const token = req.header('Authorization').replace('Bearer ', '');

    if (!token) return res.status(401).json({ msg: 'No token, authorization denied' });

    try {
        const decoded = jwt.verify(token, 'secretkey');
        req.user = decoded;
        next();
    } catch (err) {
        res.status(401).json({ msg: 'Token is not valid' });
    }
};

// Routes for dashboard actions (new record, view all, bulk upload)
// Add these routes here

app.listen(3000, () => {
    console.log('Server started on port 3000');
});